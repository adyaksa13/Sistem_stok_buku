<?php
namespace SistemHelper; 

function formatRupiah($angka)
{
    return "Rp " . number_format($angka, 0, ",", ".");
}
?>